from django.contrib import admin
from django.urls import path
from crudapp import views

urlpatterns = [
   
    path('ingreso/', views.IndexView.as_view(), name='index'),
    path('', views.Lab, name='Lab'),
    #path('dashboards',views.pivot_data, name='pivot_data'),
    path('ingreso/crearEnsayo/ajustes', views.ajustes, name='ajustes'),
    path('muestra/<int:pk>/', views.info, name='info'),
    path('muestra/edit/<int:pk>/', views.edit, name='edit'),
    path('ingreso/crear/', views.crear, name='crear'),
    path('muestra/delete/<int:pk>/', views.delete, name='delete'),
    path('ingreso/crearCliente/', views.crearCliente, name='crearCliente'),
    path('ingreso/crearAnalista/', views.crearAnalista, name='crearAnalista'),
    path('ingreso/crearConductividad/', views.crearConductividad, name='crearConductividad'),
    path('ingresoConductividad/', views.IndexConductividadView.as_view(), name='indexConductividad'),
    path('ingresoEnsayo/', views.IndexEnsayoView.as_view(), name='indexEnsayo'),
    path('ensayo/<int:pk>/', views.infoEnsayo, name='infoEnsayo'),
    path('ensayo/edit/<int:pk>/', views.editEnsayo, name='editEnsayo'),
    path('ensayo/delete/<int:pk>/', views.deleteEnsayo, name='deleteEnsayo'),
    path('ingreso/crearEnsayo/', views.crearEnsayo, name='crearEnsayo'),
    path('ingreso/guardarEnsayo/', views.guardarEnsayo, name='guardarEnsayo'),
    path('ingreso/crearEnsayo/Equipo', views.crearEnsayoEquipo, name='crearEnsayoEquipo'),
    path('ingreso/crearEnsayo/Mediciones', views.crearEnsayoMediciones, name='crearEnsayoMediciones'),

    ############################Equipos###########################
    
    path('ingresoEquipo/', views.IndexEquipoView.as_view(), name='indexEquipo'),
    path('equipo/<int:pk>/', views.infoEquipo, name='infoEquipo'),
    path('equipo/edit/<int:pk>/', views.editEquipo, name='editEquipo'),
    path('equipo/delete/<int:pk>/', views.deleteEquipo, name='deleteEquipo'),
    path('ingreso/crearEquipo/', views.crearEquipo, name='crearEquipo'),
    path('equipo/ajust/<int:pk>/', views.ajustEquipo, name='ajustEquipo'),
]