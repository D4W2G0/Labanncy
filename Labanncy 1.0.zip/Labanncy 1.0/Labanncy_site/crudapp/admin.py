from django.contrib import admin
from .models import Contact
from .models import Cliente
from .models import Analista
from .models import Conductividad
from .models import Equipo
from .models import Analisis
from .models import Muestra
from .models import Material
from .models import Ensayo, Ensayo1, MR, Ajuste, Duplicado


# Register your models here.

#admin.site.register(Contact)
##admin.site.register(Cliente)
#admin.site.register(Analista)
#admin.site.register(Conductividad)
#admin.site.register(Equipo)
#admin.site.register(Analisis)
#admin.site.register(Muestra)
#admin.site.register(Material)
#admin.site.register(Ensayo1)
#admin.site.register(MR)
#admin.site.register(Ajuste)
#@admin.register(Ensayo)
#class EnsayoAdmin(admin.ModelAdmin):
 #list_display = ('ID_Ensayo', 'Analisis', 'Muestras', 'Equipo', 'Medicion1','Medicion2','FechaCreacion')
 #list_filter = ('Equipo', 'FechaCreacion',)
 #search_fields = ('ID_Ensayo',)
 #prepopulated_fields = {'slug': ('title',)}
 #raw_id_fields = ('Analisis',)
 #date_hierarchy = 'FechaCreacion'
 #ordering = ('status', 'publish')

@admin.register(Ensayo1)
class Ensayo1Admin(admin.ModelAdmin):
 list_display = ('ID_Ensayo', 'Analisis', 'Muestras', 'Equipo', 'Medicion1','Medicion2','FechaCreacion')
 list_filter = ('Equipo', 'FechaCreacion',)
 search_fields = ('ID_Ensayo',)
 date_hierarchy = 'FechaCreacion'
 
@admin.register(Ajuste)
class AjusteAdmin(admin.ModelAdmin):
 list_display = ('ID_Ajuste', 'Equipo', 'MR', 'valor', 'Fecha_Ajuste')
 list_filter = ('Equipo', 'Fecha_Ajuste',)
 search_fields = ('ID_Ensayo',)
 date_hierarchy = 'Fecha_Ajuste'

@admin.register(Duplicado)
class DuplicadoAdmin(admin.ModelAdmin):
 list_display = ('ID_Duplicado', 'Muestra', 'Analisis', 'Equipo', 'Medicion1','Medicion2','Observacion','Fecha_duplicado')
 list_filter = ('Equipo', 'Fecha_duplicado','Analisis',)
 search_fields = ('ID_Duplicado',)
 date_hierarchy = 'Fecha_duplicado'

@admin.register(Analisis)
class AnalisisAdmin(admin.ModelAdmin):
 list_display = ('ID_Analisis', 'Nombre')
 search_fields = ('Nombre',)

@admin.register(Material)
class MaterialAdmin(admin.ModelAdmin):
 list_display = ('ID_Material', 'Nombre')
 search_fields = ('Nombre',)

@admin.register(Muestra)
class MuestraAdmin(admin.ModelAdmin):
 list_display = ('ID_Muestra', 'Nombre', 'Material', 'Analisis','createdAt')
 list_filter = ('Analisis', 'createdAt','Material')
 search_fields = ('ID_Muestra',)
 date_hierarchy = 'createdAt'
 
@admin.register(Equipo)
class EquipoAdmin(admin.ModelAdmin):
 list_display = ('ID_Equipo', 'Analisis', 'Codigo', 'Serial', 'Marca','Modelo','Fecha_Calibracion')
 list_filter = ('Analisis', 'Marca')
 search_fields = ('ID_Equipo',)
 #date_hierarchy = 'createdAt'

@admin.register(MR)
class MRAdmin(admin.ModelAdmin):
 list_display = ('ID_MR', 'Analisis', 'Codigo', 'Rango', 'Lote')
 list_filter = ('Analisis', 'Codigo')
 search_fields = ('ID_MR',)
 #date_hierarchy = 'createdAt'