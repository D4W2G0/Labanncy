from django.db import models

# Create your models here.


class Cliente(models.Model):
    ID_Cliente = models.AutoField(primary_key = True)
    Nombre= models.CharField("Nombre", max_length=255, blank = True, null = True)
    RUC = models.CharField("RUC", max_length=255, blank = True, null = True)
    Ciudad = models.CharField("Ciudad", max_length=255, blank = True, null = True)
    Direccion = models.CharField("Direccion", max_length=255, blank = True, null = True)
    Telefono = models.CharField("Telefono", max_length=255, blank = True, null = True)
    Celular = models.CharField("Celular", max_length=255, blank = True, null = True)
    createdAt = models.DateTimeField("Created At", auto_now_add=True)
    usuario= models.CharField("usuario", max_length=255, blank = True, null = True)
    
    def __str__(self):
        return str(self.Nombre) 

class Contact(models.Model):
    ID_Muestra = models.AutoField(primary_key = True)
    Material = models.CharField("Material", max_length=255, blank = True, null = True)
    Ensayo = models.CharField("Ensayo", max_length=255, blank = True, null = True)
    
    createdAt = models.DateTimeField("Created At", auto_now_add=True)
    
 

    def __str__(self):
        return self.Material




class Analista(models.Model):

    ID_Analista = models.AutoField(primary_key = True)
    Foto = models.ImageField("Foto", upload_to='Fotos/Analistas/')
    PrimerNombre = models.CharField("PrimerNombre", max_length=255, blank = True, null = True)
    SegundoNombre = models.CharField("SegundoNombre", max_length=255, blank = True, null = True)
    PrimerApellido = models.CharField("PrimerApellido", max_length=255, blank = True, null = True)
    SegundoApellido = models.CharField("SegundoApellido", max_length=255, blank = True, null = True)
    TipoSangre = models.CharField("TipoSangre", max_length=3, blank = True, null = True)
    Domcilio = models.CharField("Domicilio", max_length=255, blank = True, null = True)
    Telefono = models.CharField("Telefono", max_length=255, blank = True, null = True)
    Celular = models.CharField("Celular", max_length=255, blank = True, null = True)
    Fecha_nacimiento= models.DateTimeField("Fecha_nacimiento")
    createdAt = models.DateTimeField("Created At", auto_now_add=True)

    def __str__(self,):
            return str(self.PrimerNombre)

class Analisis(models.Model):

    ID_Analisis = models.AutoField(primary_key = True)
    Nombre = models.CharField("Nombre", max_length=255, blank = True, null = True)
    
    
    def __str__(self):

        return (str(self.ID_Analisis))
        
class MR(models.Model):

    ID_MR = models.AutoField(primary_key = True)
    Analisis = models.ForeignKey(Analisis , on_delete = models.CASCADE)
    Codigo = models.CharField("Codigo", max_length=255, blank = True, null = True)
    Rango = models.CharField("Rango", max_length=255, blank = True, null = True)
    Lote = models.CharField("Lote", max_length=255, blank = True, null = True)

    
    
    def __str__(self):
        return str(self.Codigo)



class Equipo(models.Model):

    ID_Equipo = models.AutoField(primary_key = True)
    Analisis = models.ForeignKey(Analisis , on_delete = models.CASCADE)
    Codigo = models.CharField("Codigo", max_length=255, blank = True, null = True)
    Serial = models.CharField("Serial", max_length=255, blank = True, null = True)
    Marca = models.CharField("Marca", max_length=255, blank = True, null = True)
    Modelo = models.CharField("Modelo", max_length=255, blank = True, null = True)
    Fecha_Calibracion = models.DateField("Fecha_Calibracion", blank = True, null = True)


    def __str__(self):
        return str(self.Codigo)


class Ajuste(models.Model):

    ID_Ajuste = models.AutoField(primary_key = True)
    Equipo = models.CharField("Equipo", max_length=255, blank = True, null = True)
    MR = models.CharField("MR", max_length=255, blank = True, null = True)
    valor = models.CharField("valor", max_length=255, blank = True, null = True)
    Fecha_Ajuste = models.DateField("Fecha_Ajuste", auto_now_add=True)

    def __str__(self):
        return str(self.Equipo)

class Duplicado(models.Model):

    ID_Duplicado = models.AutoField(primary_key = True)
    Muestra = models.CharField("Muestra", max_length=255, blank = True, null = True)
    Analisis = models.CharField("Analisis", max_length=255, blank = True, null = True)
    Equipo = models.CharField("Equipo", max_length=255, blank = True, null = True)
    Medicion1 = models.CharField("Medicion1", max_length=255, blank = True, null = True)
    Medicion2 = models.CharField("Medicion2", max_length=255, blank = True, null = True)
    Observacion= models.CharField("Observacion", max_length=255, blank = True, null = True)
    Fecha_duplicado = models.DateField("Fecha_duplicado", auto_now_add=True)

class Material(models.Model):

    ID_Material = models.AutoField(primary_key = True)
    Nombre = models.CharField("Nombre", max_length=255, blank = True, null = True)
    
    def __str__(self):
        return str(self.Nombre)


class Muestra(models.Model):

    ID_Muestra = models.AutoField(primary_key = True)
    Nombre = models.CharField("Nombre", max_length=255, blank = True, null = True)
    Material = models.ForeignKey(Material , on_delete = models.CASCADE)
    Analisis = models.ForeignKey(Analisis , on_delete = models.CASCADE)
    #Cliente = models.ForeignKey (Cliente, on_delete = models.CASCADE)
    Hecho = models.CharField("Hecho", max_length=255, blank = True, null = True)
    createdAt = models.DateTimeField("Created At", auto_now_add=True)

    def __str__(self):
        return (str(self.Nombre) ) ###############+"  "+ str(self.Material)#####

class Conductividad(models.Model):

    ID_Conductividad = models.AutoField(primary_key = True)
    Muestra = models.ForeignKey(Muestra , on_delete = models.CASCADE)
    

    def __str__(self):
        return str(self.Muestra)


class Ensayo1(models.Model):

    ID_Ensayo = models.AutoField(primary_key = True)
    Analisis = models.CharField("Analisis", max_length=255, blank = True, null = True)
    Muestras = models.CharField("Muestras", max_length=255, blank = True, null = True)
    Equipo = models.CharField("Equipo", max_length=255, blank = True, null = True)
    Medicion1 = models.CharField("Medicion1", max_length=255, blank = True, null = True)
    Medicion2 = models.CharField("Medicion2", max_length=255, blank = True, null = True)
    
    FechaCreacion = models.DateTimeField("FechaCreacion", auto_now_add=True)

    def __str__(self):
        return str(self.ID_Ensayo) 

class Ensayo(models.Model):

    ID_Ensayo = models.AutoField(primary_key = True)
    Analisis = models.ForeignKey(Analisis , on_delete = models.CASCADE, blank = True, null = True)
    Muestras = models.ForeignKey(Muestra , on_delete = models.CASCADE, blank = True, null = True)
    Equipo = models.ForeignKey(Equipo , on_delete = models.CASCADE , blank = True, null = True)
    Medicion1 = models.CharField("Medicion1", max_length=255, blank = True, null = True)
    Medicion2 = models.CharField("Medicion2", max_length=255, blank = True, null = True)
    
    FechaCreacion = models.DateTimeField("FechaCreacion", auto_now_add=True)

    def __str__(self):
        return str(self.ID_Ensayo) +" | "+ str(self.Analisis)+" | "+ str(self.Muestras)

###################################DASHBOARDS################################

class Order(models.Model):
    product_category = models.CharField(max_length=20)
    payment_method = models.CharField(max_length=50)
    shipping_cost = models.CharField(max_length=50)
    unit_price = models.DecimalField(max_digits=5, decimal_places=2)
    