from django.shortcuts import render, redirect, get_object_or_404, reverse,  HttpResponseRedirect
from django.contrib import messages
from .models import Muestra, Analisis,Cliente,Conductividad,Equipo,Ensayo, Ensayo1,Order, MR 
from .forms import MuestraForm,ClienteForm,AnalistaForm, AjusteForm,ConductividadForm,AnalisisForm,EquiposForm,EnsayoForm,EnsayoequipoForm
from django.views.generic import ListView, DetailView, CreateView 
from django.http import JsonResponse 
from django.core import serializers

############################Laboratorio##########################


def Lab(request):
    return render(request,"crudapp/homeLab.html")



######################################################################
class IndexView(ListView):
    template_name = 'crudapp/index.html'
    context_object_name = 'muestra_list'
    
    def get_queryset(self):
        return Muestra.objects.all()

class MuestraDetailView(DetailView):
    model = Muestra
    template_name = 'crudapp/muestra-detail.html'
    
       

def crear(request):
    if request.method == 'POST':
        form = MuestraForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    form = MuestraForm()

    return render(request,'crudapp/create.html',{'form': form})

def info(request, pk, template_name='crudapp/muestra-detail.html'):
    muestra = get_object_or_404(Muestra, pk=pk)
    form = MuestraForm( request.POST or None, instance=muestra)
   
    return render(request, template_name, {'form':form})
    

def edit(request, pk, template_name='crudapp/edit.html'):
    muestra = get_object_or_404(Muestra, pk=pk)
    form = MuestraForm( request.POST or None, instance=muestra)
    if form.is_valid():
        form.save()
        return redirect('index')
    return render(request, template_name, {'form':form})

def delete(request, pk, template_name='crudapp/confirm_delete.html'):
    muestra = get_object_or_404(Muestra, pk=pk)
    if request.method=='POST':
        muestra.delete()
        return redirect('index')
    return render(request, template_name, {'object':muestra})

########################################

class ClienteView(ListView):
    template_name = 'crudapp/index.html'
    context_object_name = 'cliente_list'
    
    def get_queryset(self):
        return Cliente.objects.all()

class ClienteDetailView(DetailView):
    model = Cliente
    template_name = 'crudapp/Cliente-detail.html'

def crearCliente(request):
    if request.method == 'POST':
        form = ClienteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    form = ClienteForm()

    return render(request,'crudapp/crearCliente.html',{'form': form})

def editCliente(request, pk, template_name='crudapp/edit.html'):
    contact = get_object_or_404(Contact, pk=pk)
    form = ClienteForm(request.POST or None, instance=post)
    if form.is_valid():
        form.save()
        return redirect('index')
    return render(request, template_name, {'form':form})

def deleteCliente(request, pk, template_name='crudapp/confirm_delete.html'):
    cliente = get_object_or_404(Contact, pk=pk)
    if request.method=='POST':
        cliente.delete()
        return redirect('index')
    return render(request, template_name, {'object':cliente})

########################################

def crearAnalista(request):
    if request.method == 'POST':
        form = AnalistaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('crearAnalista')
    form = AnalistaForm()

    return render(request,'crudapp/crearAnalista.html',{'form': form})

############### Conductividad #########################

class IndexConductividadView(ListView):
    template_name = 'crudapp/indexConductividad.html'
    context_object_name = 'conductividad_list'
    
    def get_queryset(self):
        return Conductividad.objects.all()


def crearConductividad(request):
    if request.method == 'POST':
        form = ConductividadForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('indexConductividad')
    form = ConductividadForm()

    return render(request,'crudapp/crearConductividad.html',{'form': form})

############### Ensayo #########################

class IndexEnsayoView(ListView):
    template_name = 'crudapp/indexEnsayo.html'
    context_object_name = 'ensayo_list'
    
    def get_queryset(self):
        return Ensayo1.objects.all()


def crearEnsayo(request):
    analisis = Analisis.objects.all()
    muestras = Muestra.objects.all()
    equipos = Equipo.objects.all()
    mr = MR.objects.all()
    
    
    
        
    return render(request,'crudapp/crearEnsayo1.html',{'datosAnalisis':analisis, 'datosMuestras':muestras, 'datosEquipos':equipos, 'datosMR':mr})

def guardarEnsayo(request):
    if request.method!="POST":
        return HttpResponseRedirect(reverse("crearEnsayo1"))
    else:
        
        Anali=request.POST.get("anali")
        Muest=request.POST.get("muest")
        Equip=request.POST.get("equip")
        Medic=request.POST.get("medic")
       
        
    try:
            ensayo=Ensayo1(Analisis= Anali, Muestras= Muest, Equipo=Equip, Medicion1=Medic) 
            ensayo.save()
            messages.success(request,"Ensayo Guardado")
            return HttpResponseRedirect(reverse('indexEnsayo'))
    except:
            messages.error(request,"Error al guardar ensayo")
            return HttpResponseRedirect(reverse('crearEnsayo'))    


def crearEnsayoEquipo(request):
    if request.method == 'POST':
        form = EnsayoequipoForm(request.POST)
        #equipo = Equipo.objects.get(ID_Equipo=form) 
        #if equipo.Fecha_Calibracion < date.today():
        if form.is_valid():
             form.save()
             return redirect('crearEnsayoEquipo')
    form = EnsayoequipoForm()

    return render(request,'crudapp/crearEnsayoEquipo.html',{'form': form})



def crearEnsayoMediciones(request):
    if request.method == 'POST':
        form = EnsayoequipoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('indexConductividad')
    form = EnsayoequipoForm()

    return render(request,'crudapp/crearEnsayoEquipo.html',{'form': form})

def infoEnsayo(request, pk, template_name='crudapp/Ensayo-detail.html'):
    ensayo = get_object_or_404(Ensayo1, pk=pk)
    form = EnsayoForm( request.POST or None, instance=ensayo)
   
    return render(request, template_name, {'form':form})
    

def editEnsayo(request, pk, template_name='crudapp/editEnsayo.html'):
    ensayo = get_object_or_404(Ensayo1, pk=pk)
    form = EnsayoForm( request.POST or None, instance=ensayo)
    if form.is_valid():
        form.save()
        return redirect('indexEnsayo')
    return render(request, template_name, {'form':form})

def deleteEnsayo(request, pk, template_name='crudapp/confirm_deleteEnsayo.html'):
    ensayo = get_object_or_404(Ensayo1, pk=pk)
    if request.method=='POST':
        ensayo.delete()
        return redirect('indexEnsayo')
    return render(request, template_name, {'object':ensayo})


#############################DASHBOARDS######################################



###########################EQUIPOS#########################################

class IndexEquipoView(ListView):
    template_name = 'crudapp/indexEquipo.html'
    context_object_name = 'equipo_list'
    
    def get_queryset(self):
        return Equipo.objects.all()

def crearEquipo(request):
    if request.method == 'POST':
        form = EquiposForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('crearEquipo')
    form = EquiposForm()

    return render(request,'crudapp/crearEquipo.html',{'form': form})

def infoEquipo(request, pk, template_name='crudapp/Equipo-detail.html'):
    equipo = get_object_or_404(Equipo, pk=pk)
    form = EquiposForm( request.POST or None, instance=equipo)
   
    return render(request, template_name, {'form':form})
    

def editEquipo(request, pk, template_name='crudapp/editEquipo.html'):
    equipo = get_object_or_404(Equipo, pk=pk)
    form = EquiposForm( request.POST or None, instance=equipo)
    if form.is_valid():
        form.save()
        return redirect('indexEquipo')
    return render(request, template_name, {'form':form})

def deleteEquipo(request, pk, template_name='crudapp/confirm_deleteEquipo.html'):
    equipo = get_object_or_404(Equipo, pk=pk)
    if request.method=='POST':
        equipo.delete()
        return redirect('indexEquipo')
    return render(request, template_name, {'object':equipo})

def ajustEquipo(request, template_name='crudapp/ajustEquipo.html'):
    analisis = Analisis.objects.all()
    equipos = Equipo.objects.all()
    mr = MR.objects.all()
    if request.method == 'POST':
        form = EquiposForm(request.POST)
        if form.is_valid():
            form.save()
            
    form = EquiposForm()
    
    # form = AjusteForm( request.POST or None, instance=equipo)
    # if form.is_valid():
        
    #     form.save()
    #     return redirect('indexEnsayo')
    return render(request, template_name, {'form':form,'datosAnalisis':analisis, 'datosEquipos':equipos, 'datosMR':mr})




def ajustes(request):
    analisis = Analisis.objects.all()
    muestras = Muestra.objects.all()
    equipos = Equipo.objects.all()
    mr = MR.objects.all()
    if request.method == 'POST':
        form = AjusteForm(request.POST)
        if form.is_valid():
            form.save()
            
    
    form = AjusteForm()

    return render(request,'crudapp/crearAjuste.html',{'datosAnalisis':analisis, 'datosMuestras':muestras, 'datosEquipos':equipos, 'datosMR':mr})