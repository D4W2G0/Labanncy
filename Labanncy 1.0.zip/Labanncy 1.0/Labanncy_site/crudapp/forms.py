from django import forms
from .models import Contact
from .models import Cliente
from .models import Analista
from .models import Conductividad
from .models import Equipo
from .models import Analisis
from .models import Muestra, Ajuste
from .models import Ensayo1, MR

class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = "__all__"

class MuestraForm(forms.ModelForm):
    class Meta:
        model = Muestra
        fields = "__all__"        

class ClienteForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = "__all__"

class AnalistaForm(forms.ModelForm):
    class Meta:
        model = Analista
        fields = "__all__"


class MRForm(forms.ModelForm):
    class Meta:
        model = MR
        fields = "__all__"

class EquiposForm(forms.ModelForm):
    class Meta:
        model = Equipo
        fields = "__all__"

class AjusteForm(forms.ModelForm):
    class Meta:
        model = Ajuste
        fields = "__all__"

class AnalisisForm(forms.ModelForm):
    class Meta:
        model = Analisis
        fields = "__all__"

class ConductividadForm(forms.ModelForm):
    class Meta:
        model = Conductividad
        fields = "__all__"

class MaterialForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = "__all__"

class EnsayoForm(forms.ModelForm):
    class Meta:
        model = Ensayo1
        fields = "__all__"


class EnsayoequipoForm(forms.ModelForm):
    class Meta:
        model = Ensayo1
        fields = ('Equipo',)

class EnsayoMedicionForm(forms.ModelForm):
    class Meta:
        model = Ensayo1
        fields = ('Medicion1','Medicion2')
       