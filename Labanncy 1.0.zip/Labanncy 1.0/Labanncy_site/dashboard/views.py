from django.http import JsonResponse
from django.shortcuts import render
from django.core import serializers
from crudapp.models import  Ajuste, Ensayo1

def dashboard_Ensayos(request):
    return render(request, 'dashboard_Ensayos.html', {})



def pivot_Ensayos(request):
    dataset = Ensayo1.objects.all()
    data = serializers.serialize('json', dataset)
    return JsonResponse(data, safe=False)


