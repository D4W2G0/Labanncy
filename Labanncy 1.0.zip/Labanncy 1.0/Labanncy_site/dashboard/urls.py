from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard_Ensayos, name='dashboard_Ensayos'),
   
    path('data', views.pivot_Ensayos, name='pivot_Ensayos'),
]
