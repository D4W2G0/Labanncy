from django.shortcuts import render, redirect, get_object_or_404, reverse,  HttpResponseRedirect
from django.contrib import messages
from django.contrib.auth import views
from django.contrib.auth import authenticate, login
from .forms import UserCreateForm

def home(request):
    return render(request,"Web/base.html")

def signup(request):
    if request.method == 'POST':
        form = UserCreateForm(request.POST)
        if form.is_valid():
            new_user = form.save()
            new_user = authenticate(
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password1']
            )
            login(request, new_user)
            return redirect('home')
    else:
        form = UserCreateForm()
    return render(request, 'registration/signup.html', {'form': form})

