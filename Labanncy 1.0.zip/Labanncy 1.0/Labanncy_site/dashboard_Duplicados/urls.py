from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard_Duplicados, name='dashboard_Duplicados'),
    path('data', views.pivot_Duplicados, name='pivot_Duplicados'),
]   
