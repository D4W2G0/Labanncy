from django.http import JsonResponse
from django.shortcuts import render

from django.core import serializers
from crudapp.models import  Duplicado

def dashboard_Duplicados(request):
    return render(request, 'dashboard_Duplicados.html', {})



def pivot_Duplicados(request):
    dataset = Duplicado.objects.all()
    data = serializers.serialize('json', dataset)
    return JsonResponse(data, safe=False)


