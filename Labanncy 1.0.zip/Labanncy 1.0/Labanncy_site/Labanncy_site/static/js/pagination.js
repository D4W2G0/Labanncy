  $( document ).ready(function(){ 
      commandPager();
  });

function commandPager()
{ 
  var maxCommandsPerPage = 6;
  var totalCommands = $('#current-commands > div').length;
 
  var numOfPages = totalCommands / maxCommandsPerPage;
  var allPages = Math.ceil(numOfPages)
  for(var i = 1; i <= allPages ; i++)
    {  
      $('#command-pager').append('<li class="page">' + i +'</li>')
    }
}